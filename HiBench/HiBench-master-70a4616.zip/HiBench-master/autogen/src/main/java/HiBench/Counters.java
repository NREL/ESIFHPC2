package HiBench;

public enum Counters {
	BYTES_DATA_GENERATED
}
